package com.thaer.chessacademy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Move
import com.github.bhlangonijr.chesslib.Square

private val Gold = Color(0xFFD5AD57)
private val Dark = Color(0xFF111318)
private val Panel = Color(0xFF1C2028)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AcademyApp() }
    }
}

@Composable
private fun AcademyApp() {
    var page by remember { mutableStateOf("home") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Dark, surface = Panel)) {
        Scaffold(containerColor = Dark) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
                Text("THAER CHESS ACADEMY", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("أكاديمية الشطرنج", color = Color.LightGray, fontSize = 14.sp)
                Spacer(Modifier.height(18.dp))
                when (page) {
                    "board" -> BoardScreen(onBack = { page = "home" })
                    "lessons" -> LessonsScreen(onBack = { page = "home" })
                    else -> HomeScreen(onBoard = { page = "board" }, onLessons = { page = "lessons" })
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onBoard: () -> Unit, onLessons: () -> Unit) {
    Text("مرحباً بك في طريقك لإتقان الشطرنج", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(18.dp))
    MenuCard("رقعة التدريب", "تدرّب على الرقعة وتعرّف إلى المربعات", onBoard)
    MenuCard("الأكاديمية", "دروس للمبتدئين ومبادئ اللعب", onLessons)
    MenuCard("خطة التطوير", "قريباً: برنامج تدريبي متدرج", {})
    Spacer(Modifier.weight(1f))
    Text("الإصدار التجريبي 0.1.0", color = Color.Gray, fontSize = 12.sp)
}

@Composable
private fun MenuCard(title: String, subtitle: String, action: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp).clickable { action() },
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, color = Color.LightGray, fontSize = 13.sp)
        }
    }
}

@Composable
private fun BoardScreen(onBack: () -> Unit) {
    val board = remember { Board() }
    var selected by remember { mutableStateOf<Square?>(null) }
    var positionVersion by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("الأبيض يبدأ اللعب") }
    val legalMoves = remember(positionVersion) { board.legalMoves }
    val selectedMoves = remember(selected, positionVersion) {
        selected?.let { from -> legalMoves.filter { it.from == from } } ?: emptyList()
    }

    TextButton(onClick = onBack) { Text("رجوع", color = Gold) }
    Text("رقعة الشطرنج", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
    Text(message, color = Gold, fontSize = 14.sp)
    Spacer(Modifier.height(12.dp))

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        for (rank in 7 downTo 0) {
            Row {
                for (file in 0..7) {
                    val square = Square.values()[rank * 8 + file]
                    val piece = board.getPiece(square).toString()
                    val isSelected = selected == square
                    val isTarget = selectedMoves.any { it.to == square }
                    val light = (rank + file) % 2 == 1
                    val bg = when {
                        isSelected -> Gold
                        isTarget -> Color(0xFF91A86A)
                        light -> Color(0xFFE5D7B8)
                        else -> Color(0xFF765B3F)
                    }
                    Box(
                        Modifier.weight(1f).aspectRatio(1f).background(bg)
                            .clickable {
                                val current = selected
                                if (current == null) {
                                    if (piece != "NONE" && piece != "null") selected = square
                                } else {
                                    val candidate = legalMoves.firstOrNull { it.from == current && it.to == square }
                                    if (candidate != null) {
                                        board.doMove(candidate)
                                        selected = null
                                        positionVersion++
                                        message = when {
                                            board.isMated -> "كش مات! انتهت المباراة"
                                            board.isDraw -> "تعادل"
                                            board.isKingAttacked -> "كش!"
                                            else -> if (board.sideToMove.toString() == "WHITE") "دور الأبيض" else "دور الأسود"
                                        }
                                    } else {
                                        selected = if (piece != "NONE" && piece != "null") square else null
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(pieceSymbol(piece), fontSize = 27.sp,
                            color = if (piece.startsWith("WHITE")) Color.White else Color(0xFF171717))
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = {
            board.loadFromFen(Board.STARTING_POSITION)
            selected = null
            positionVersion++
            message = "بدأت مباراة جديدة — الأبيض يبدأ"
        }) { Text("مباراة جديدة", color = Gold) }
        OutlinedButton(onClick = {
            if (board.undoMove()) {
                selected = null
                positionVersion++
                message = "تم التراجع عن النقلة"
            }
        }) { Text("تراجع", color = Gold) }
    }
    Spacer(Modifier.height(8.dp))
    Text("المربعات الخضراء هي النقلات القانونية المتاحة للقطعة المحددة.", color = Color.LightGray, fontSize = 12.sp)
}

private fun pieceSymbol(piece: String): String = when (piece) {
    "WHITE_KING" -> "♔"; "WHITE_QUEEN" -> "♕"; "WHITE_ROOK" -> "♖"
    "WHITE_BISHOP" -> "♗"; "WHITE_KNIGHT" -> "♘"; "WHITE_PAWN" -> "♙"
    "BLACK_KING" -> "♚"; "BLACK_QUEEN" -> "♛"; "BLACK_ROOK" -> "♜"
    "BLACK_BISHOP" -> "♝"; "BLACK_KNIGHT" -> "♞"; "BLACK_PAWN" -> "♟"
    else -> ""
}

@Composable
private fun LessonsScreen(onBack: () -> Unit) {
    TextButton(onClick = onBack) { Text("رجوع", color = Gold) }
    Text("الدروس الأساسية", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    val lessons = listOf(
        "1. الهدف من لعبة الشطرنج" to "الهدف هو تحقيق كش مات لملك الخصم.",
        "2. أسماء القطع" to "ملك، وزير، قلعة، فيل، حصان، وبيدق.",
        "3. حركة القطع" to "لكل قطعة طريقة حركة مختلفة، ويجب تعلمها قبل بدء اللعب.",
        "4. الكش والكش مات" to "الكش تهديد مباشر للملك، والكش مات يعني عدم وجود أي رد قانوني ينقذه."
    )
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(lessons.size) { i ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(lessons[i].first, color = Gold, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(lessons[i].second, color = Color.White)
                }
            }
        }
    }
}
