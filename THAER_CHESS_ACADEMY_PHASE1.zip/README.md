# THAER CHESS ACADEMY

Android Native starter project using Kotlin and Jetpack Compose.

## Current prototype
- Arabic-first home screen.
- Basic training board display (selection only; legal move logic is not implemented yet).
- Four introductory lesson cards.
- GitHub Actions workflow to build a debug APK and publish it as an artifact.

## Build
Run `gradle assembleDebug` with JDK 17 and Android SDK platform 35 installed.

This is an initial project foundation, not the completed chess academy. Move validation, PGN, persistent games, Stockfish integration, advanced lessons, and analysis are planned subsequent milestones.
